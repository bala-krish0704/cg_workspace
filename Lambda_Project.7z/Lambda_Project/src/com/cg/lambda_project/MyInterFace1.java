package com.cg.lambda_project;

public interface MyInterFace1 {
	String getData(String s);

}
