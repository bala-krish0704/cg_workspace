package com.cg.lambda_project;

public interface MyInterFace {
	int getArrayValue(int[] arr);
}
