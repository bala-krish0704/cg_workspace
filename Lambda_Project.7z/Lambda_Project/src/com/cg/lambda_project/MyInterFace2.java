package com.cg.lambda_project;

public interface MyInterFace2 {
	int getValue(int a);

}
