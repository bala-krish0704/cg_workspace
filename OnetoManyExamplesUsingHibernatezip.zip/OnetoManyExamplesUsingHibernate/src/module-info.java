/**
 * 
 */
/**
 * @author jamala
 *
 */
module OnetoManyExamplesUsingHibernate {
}